## WEB

1. DB
    
    * 사용자 디비 : Signup, login
    * 키워드 디비 : 회사-